This is a merged patch CIA for Story of Seasons: Trio of Towns (USA).

It contains the following:

- Everything added by the official 1.1 update
- Version 5.0.1 of Silrae's "True Love Edition" patch
- Version 1.2 of ubergeek77's "Hamtaro and Cheburashka Restoration Patch"

Please note:

- This is only for the USA version of the game, with TitleID 000400000019f500,
  and won't work on the PAL version.

- This should work with both digital and cartridge versions of the game.

- This should be compatible with save files from games without this patch.

- This .cia REPLACES the 1.1 update. If you have the 1.1 update already installed, uninstall it
  first before installing this one.

- Also included in this archive is the DLC unlocker .cia, which adds Stephanie and Woofio as
  marriage candidates. Install this to unlock the DLC.

- None of Silrae's "Optional Patches" for TLE have been merged into this one. If you want
  to use any of those, you can add them yourself via LayeredFS or Citra's Game Modding feature.
  However, do NOT use Silrae's Hamtaro Compatibility Patch. That has already been included.

*** IMPORTANT ***
In *addition to* installing these .cia files, please copy the folder *inside* of "SD Files" to the
root of your SD card **and enable LayeredFS for this game**:

https://gist.github.com/PixelSergey/5dbb4a9b90d290736353fa58e4fcbb42

If you are using Citra, you can use the Game Modding feature instead:

https://citra-emu.org/help/feature/game-modding/

************************************************************************
***     If you skip this step, cutscenes with Hamtaro will CRASH     ***
************************************************************************

If you are using a real 3DS, and a digital copy of the game, please also be aware of a LayeredFS
bug impacting this game that will cause a crash if you have the Mushroom Log item on your farm: 

https://github.com/LumaTeam/Luma3DS/issues/1514

This bug DOES NOT apply to Citra. You can ignore this warning if you use Citra.

If you use a real 3DS and a digital copy of the game, to avoid the bug you can either:
- Disable LayeredFS for this game after you have seen both Hamtaro cutscenes, or
- Do not add a Mushroom Log to your farm